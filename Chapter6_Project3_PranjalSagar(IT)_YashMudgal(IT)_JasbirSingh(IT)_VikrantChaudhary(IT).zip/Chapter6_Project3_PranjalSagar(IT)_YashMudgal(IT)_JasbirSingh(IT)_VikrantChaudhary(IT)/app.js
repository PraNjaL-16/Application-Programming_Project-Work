document.querySelector('.artThumb1').addEventListener('mouseover',function() {
    
    document.querySelector('.artThumb1').classList.toggle('zoom');

});

document.querySelector('.artThumb1').addEventListener('mouseout',function() {
    
    document.querySelector('.artThumb1').classList.toggle('zoom');

});


document.querySelector('.artThumb2').addEventListener('mouseover',function() {
    
    document.querySelector('.artThumb2').classList.toggle('zoom');

});

document.querySelector('.artThumb2').addEventListener('mouseout',function() {
    
    document.querySelector('.artThumb2').classList.toggle('zoom');

});


document.querySelector('.artThumb3').addEventListener('mouseover',function() {
    
    document.querySelector('.artThumb3').classList.toggle('zoom');

});

document.querySelector('.artThumb3').addEventListener('mouseout',function() {
    
    document.querySelector('.artThumb3').classList.toggle('zoom');

});



document.querySelector('.artThumb4').addEventListener('mouseover',function() {
    
    document.querySelector('.artThumb4').classList.toggle('zoom');

});

document.querySelector('.artThumb4').addEventListener('mouseout',function() {
    
    document.querySelector('.artThumb4').classList.toggle('zoom');

});



document.querySelector('.artThumb5').addEventListener('mouseover',function() {
    
    document.querySelector('.artThumb5').classList.toggle('zoom');

});

document.querySelector('.artThumb5').addEventListener('mouseout',function() {
    
    document.querySelector('.artThumb5').classList.toggle('zoom');

});

